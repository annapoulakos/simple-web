angular.module('simpleWebApplication', ['ngResource']);
