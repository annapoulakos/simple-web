simple-web
==========

Simple Web is a fast, lightweight framework for building small websites.
